let cesta;
let frutas = [];
let pontos = 0;
let tempoTotal = 60;
let tempoRestante;
let estado = "inicio";
let inicioTempo;
let fraseIndex = -1;
let sabedoria = [
  "A terra ensina a ter paciência.",
  "Quem planta, colhe.",
  "Os mais velhos conhecem os segredos do tempo.",
  "A natureza fala com quem sabe ouvir.",
  "Com os avós, aprendemos mais que com livros."
];

function setup() {
  let canvas = createCanvas(600, 400);
  canvas.elt.tabIndex = 0; // permite foco
  canvas.elt.focus();      // foca no canvas automaticamente
  cesta = new Cesta();
  textFont('Georgia');
  textAlign(CENTER, CENTER);
}

function draw() {
  background(100, 200, 100);

  if (estado === "inicio") {
    telaInicial();
  } else if (estado === "jogando") {
    jogar();
  } else if (estado === "fim") {
    telaFinal();
  }
}

function telaInicial() {
  fill(255);
  textSize(28);
  text("🌾 Colheita da Sabedoria 🌾", width / 2, height / 2 - 40);
  textSize(16);
  text("Use as setas ← → para mover a cesta", width / 2, height / 2);
  text("Colete o máximo de frutas em 60 segundos!", width / 2, height / 2 + 30);
  text("Pressione BARRA DE ESPAÇO para começar", width / 2, height / 2 + 60);
}

function jogar() {
  let tempoPassado = int((millis() - inicioTempo) / 1000);
  tempoRestante = max(0, tempoTotal - tempoPassado);

  // Sol e árvore
  fill(255, 255, 100);
  ellipse(50, 50, 80);
  fill(139, 69, 19);
  rect(450, 150, 20, 100);
  fill(34, 139, 34);
  ellipse(460, 130, 100, 100);

  cesta.mostrar();
  cesta.mover();

  if (random(1) < 0.02) {
    frutas.push(new Fruta());
  }

  for (let i = frutas.length - 1; i >= 0; i--) {
    frutas[i].cair();
    frutas[i].mostrar();

    if (frutas[i].pega(cesta)) {
      frutas.splice(i, 1);
      pontos++;
      if (pontos % 5 === 0 && fraseIndex < sabedoria.length - 1) {
        fraseIndex++;
      }
    } else if (frutas[i].y > height) {
      frutas.splice(i, 1);
    }
  }

  fill(0);
  textSize(18);
  textAlign(LEFT, TOP);
  text("Frutas colhidas: " + pontos, 20, 20);
  text("Tempo restante: " + tempoRestante + "s", 20, 45);

  if (fraseIndex >= 0) {
    textSize(16);
    textAlign(CENTER);
    text(sabedoria[fraseIndex], width / 2, height - 20);
  }

  if (tempoRestante <= 0) {
    estado = "fim";
  }
}

function telaFinal() {
  background(70, 160, 70);
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(26);
  text("⏰ Tempo esgotado! ⏰", width / 2, height / 2 - 40);
  textSize(20);
  text("Frutas colhidas: " + pontos, width / 2, height / 2);
  textSize(16);
  text("Pressione R para reiniciar", width / 2, height / 2 + 40);
}

function keyPressed() {
  if (estado === "inicio" && key === ' ') {
    estado = "jogando";
    inicioTempo = millis();
    pontos = 0;
    frutas = [];
    fraseIndex = -1;
  } else if (estado === "fim" && (key === 'r' || key === 'R')) {
    estado = "inicio";
  }
}

class Cesta {
  constructor() {
    this.x = width / 2;
    this.largura = 80;
    this.altura = 20;
  }

  mostrar() {
    fill(150, 75, 0);
    rect(this.x, height - 40, this.largura, this.altura, 10);
  }

  mover() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= 5;
    } else if (keyIsDown(RIGHT_ARROW)) {
      this.x += 5;
    }
    this.x = constrain(this.x, 0, width - this.largura);
  }
}

class Fruta {
  constructor() {
    this.x = random(width);
    this.y = 0;
    this.raio = 15;
    this.vel = random(2, 4);
  }

  mostrar() {
    fill(255, 100, 100);
    ellipse(this.x, this.y, this.raio * 2);
  }

  cair() {
    this.y += this.vel;
  }

  pega(cesta) {
    return (
      this.y + this.raio > height - 40 &&
      this.x > cesta.x &&
      this.x < cesta.x + cesta.largura
    );
  }
}